GENERAL INFORMATION

1. Title of Dataset: Corpus for Complex Word Identification in Medical Spanish Texts (CWI-Med-Sp)


2. Authors: Federico Ortega Riba, Leonardo Campillos-Llanos


3. Date of data collection: 2024-07-24


4. Date of data publication on repository: 2024-11-26


5. Geographic location of data collection <latitude, longitude, or city/region, Country, continent as appropriate>:

Spain.


6. Information about funding sources that supported the collection of the data (including research project reference/acronym):

Project CLARA-MED (PID2020-116001RA-C33) funded by MCIN/AEI/10.13039/501100011033/, in project call: "Proyectos I+D+i Retos Investigación".


7. Recommended citation for this dataset: 

Federico Ortega-Riba, Leonardo Campillos-Llanos, Doaa Samy (2025) "Lexical Simplification in Spanish Texts For Patients: The Complex Word Identification Task". (Under review).


SHARING/ACCESS/CONTEXT INFORMATION

1. Usage Licenses/restrictions placed on the data (please indicate if different data files have different usage license): 

The data can be reproduced (partially or totally), as long as the source is provided. The specific details of each data source are as follows:
- Data from REEC/AEMPS: The copyright of the contents belongs to Registro Español de Ensayos Clínicos (REEC, 'Spanish Clinical Trial Register'), from the Agencia Española de Medicamentos y Productos Sanitarios (AEMPS), and the European Clinical Trials Register (EudraCT). 
The latest access to the data was April 2024 from: https://reec.aemps.es. Note that REEC updates its contents regularly, and the data in the CLARA-MeD corpus might not be updated according to the version of the online contents.
The data can be reproduced (partially or totally), as long as the source is provided.
For more information, please, check: https://www.aemps.gob.es/avisoLegal/
- Data from Aula de Pacientes (Salud Castilla y León): This work is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International license. The latest access to the data was April 2024 from: https://www.saludcastillayleon.es/AulaPacientes/es
- Data from Organización Nacional de Trasplantes: The information available on this website, unless expressly indicated to the contrary, may be reused; its total or partial reproduction, modification, distribution and communication, for commercial and non-commercial uses, is authorized, subject to the following conditions: 1) Denaturalization of the content of the information is prohibited under any circumstances. 2) The user is obliged to cite the source of the documents subject to reuse. For more information, please, check: https://www.ont.es/aviso-legal/
- Consent forms come from accredited institutions such as Fundación Rioja Salud, who gave us permission to reuse their data; and Consejería de Salud y Consumo de la Junta de Andalucía, whose data are available through a Creative Commons Attribution 3.0 License: https://www.juntadeandalucia.es/informacion/legal.html 


2. Links to publications/other research outputs that cite the data: 

N/A


3. Links to publications/other research outputs that use the data: 

Campillos-Llanos, L., Ortega-Riba, F., Terroba, A. R., Valverde-Mateos, A., & Capllonch-Carrión, A. (2024). CLARA-MeD Tool–A System to Help Patients Understand Clinical Trial Announcements and Consent Forms in Spanish. Studies in Health Technology and Informatics (pp. 95-99). IOS Press. PMID: 39176683


4. Links to other publicly accessible locations of the data:

https://github.com/fede-ortega/LS-CWI-ES/


5. Links/relationships to ancillary data sets: N/A


6. Was data derived from another source? If so, please add link where such work is located:

Source of the data:

- Aula de Pacientes (Salud Castilla y León): https://www.saludcastillayleon.es/AulaPacientes/es
- Consent forms obtained from several accredited institutions, such as Fundación Rioja Salud and Consejería de Salud y Consumo de la Junta de Andalucía: https://www.juntadeandalucia.es/organismos/saludyconsumo/areas/sistema-sanitario/derechos-garantias/paginas/ci-oncologia.html
- Patient-oriented information from Organización Nacional de Trasplantes: https://www.ont.es/
- Registro Español de Ensayos Clínicos (REEC, 'Spanish Clinical Trial Regiter'), from the Agencia Española de Medicamentos y Productos Sanitarios (AEMPS): https://cima.aemps.es; and European Clinical Trials Register (EudraCT): https://www.clinicaltrialsregister.eu/


DATA & FILE OVERVIEW

1. Folder and file List:

The corpus is made up of 225 texts. It is aimed at training models, evaluating and performing experiments on complex word identification of Spanish medical texts.

The corpus contains three text types:
• Consent forms (75 texts)
• Clinical trial announcements (75 texts)
• Patient information leaflets (75 texts)

- ANN: Contains BRAT annotated files (.ann) and corresponding text files (.txt): These are separated in three folders and subfolders (corresponding to each text type): 
 • TRAIN: 
   ▫ ci: 51 consent forms ('consentimientos informados')
   ▫ eudract: 51 clinical trial announcements from REEC and EudraCT
   ▫ info: 51 patient-oriented information leaflets
 • DEV:
   ▫ ci: 9 consent forms FALTA UNO
   ▫ eudract: 9 clinical trial announcements
   ▫ info: 9 patient-oriented information leaflets
 • TEST:
   ▫ ci: 15 consent forms
   ▫ eudract: 15 clinical trial announcements
   ▫ info: 15 patient-oriented information leaflets
- JSON files for transformer models: These are separated in TRAIN, DEV and TEST.
- CSV files with the processed data, corresponding to TRAIN, DEV and TEST data. These were used for the machine learning experiments. Each file has the following fields:
 • Token
 • Label: it encodes the class (CW, 'complex word') and if the token is the Beginning of the entity (B), if it is Inside (I) or Outside (O).


2. Relationship between files, if important: 

N/A    


3. Additional related data collected that was not included in the current data package: 

N/A


4. Are there multiple versions of the dataset? If so, please indicate where they are located:

This is the first version.


METHODOLOGICAL INFORMATION


1. Description of methods used for collection/generation of data: 

The corpus statistics and methods are explained in the following article:

Federico Ortega-Riba, Leonardo Campillos-Llanos, Doaa Samy (2025) "Lexical Simplification in Spanish Texts For Patients: The Complex Word Identification Task". (Under review).
 
    
2. Methods for processing the data: 

Manual annotation of complex words (CW) according to the criteria defined in the guideline explained in the companion article.


3. Instrument- or software-specific information needed to interpret/reproduce the data, please indicate their location:

The BRAT annotation tool is needed to display the annotated (.ann) files. To download and install BRAT, please access: https://brat.nlplab.org/


4. Standards and calibration information, if appropriate: N/A


5. Environmental/experimental conditions: N/A


6. Describe any quality-assurance procedures performed on the data: 

All 180 documents were doubly annotated by 2 annotators.
The inter-annotator agreement was computed using the F1-measure, which was computed using the BRATEval library. 
The current version of the dataset has an F1 = 84.42% (strict) and 91.58% (relaxed).


7. People involved with sample collection, processing, analysis and/or submission, please specify using CREDIT roles
https://casrai.org/credit/: 

Leonardo Campillos-Llanos: Conceptualization, Data curation, Investigation, Methodology, Validation, Writing – original draft, Funding acquisition
Federico Ortega-Riba: Data curation, Investigation, Methodology, Validation, Writing – original draft

We greatly thank the following colleagues who doubly revised a subset of texts in order to compute the inter-annotator agreement:

Ana R. Terroba Reinares (Fundación Rioja Salud): Validation
Ana Valverde Mateos (Unidad de Terminología Médica, Real Academia Nacional de Medicina de España): Validation


8. Author contact information:

Leonardo Campillos-Llanos
Instituto de Lengua, Literatura y Antropología (ILLA)
Centro de Ciencias Humanas y Sociales (CCHS)
c/Albasanz 26-28, Madrid 28037 (Spain) 
leonardo.campillos AT csic.es



DATA-SPECIFIC INFORMATION:


1. Number of variables: N/A 


2. Number of cases/rows: N/A 


3. Variable List: N/A 


4. Missing data codes: N/A 


5. Specialized formats or other abbreviations used: 

ANN (annotated BRAT files)
CSV (comma-separated values files)
JSON (JavaScript Object Notation files)


6. Dictionaries/codebooks used: N/A


7. Controlled vocabularies/ontologies used: N/A


ABBREVIATIONS:

AEMPS: Agencia Española de Medicamentos y Productos Sanitarios
CI: consentimiento informado
CW: complex word
EudraCT: European Clinical Trials Register
ONT: Organización Nacional de Trasplantes
REEC: Registro Español de Ensayos Clínicos



